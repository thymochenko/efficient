<?php include('protected/config/bootstrap.php');

$view = new ApplicationController();
$view->staticRender(array(
    'view_dirname'=>'index',
	'tpl_name'=>'mainAjax',
	'extension'=>'tpl')
);
?>