<?php /* Smarty version 2.6.21, created on 2012-09-12 18:22:08
         compiled from c:/wamp/www/concursos_new/src/ecommerce/protected/views/views.index/index_public.tpl */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dashboard - Admin Template</title>
        <?php Partial::init()->module('ApplicationController')->message('css'); ?>
        <?php Partial::init()->module('ApplicationController')->message('styleSettings'); ?>
        
        <?php Partial::init()->module('ApplicationController')->message('colorBoxSettings'); ?>
        <?php Partial::init()->module('ApplicationController')->message('javascripts'); ?>
		<?php Partial::init()->module('ApplicationController')->message('datatables'); ?>
<link rel="stylesheet" type="text/css" href="http://localhost/concursos_new/src/ecommerce/media/admin_template/css/theme.css" />
<link rel="stylesheet" type="text/css" href="http://localhost/concursos_new/src/ecommerce/media/admin_template/css/style.css" />
<script>
   var StyleFile = "theme" + document.cookie.charAt(6) + ".css";
   document.writeln('<link rel="stylesheet" type="text/css" href="http://localhost/concursos_new/src/ecommerce/media/admin_template/css/' + StyleFile + '">');
</script>
<!--[if IE]>
<link rel="stylesheet" type="text/css" href="css/ie-sucks.css" />
<![endif]-->
</head>
<body>
	<div id="container">
    	<div id="header">
        	<h1 class="topologo"><img src="http://localhost/concursos_new/src/ecommerce/media/images/esapilogo.jpg" /></h1>
    <div id="topmenu">
            	<ul>
                	<li class="current"><a href="http://localhost/concursos_new/src/ecommerce/produto/getall.html">Principal</a></li>
                    <li><a href="http://localhost/concursos_new/src/ecommerce/venda/index.html">Cursos</a></li>
                	<li><a href="http://localhost/concursos_new/src/ecommerce/users/index.html">Cadastro</a></li>
                    <li><a href="http://localhost/concursos_new/src/ecommerce/mesa/index.html">Inscritos</a></li>
                    <li><a href="http://localhost/concursos_new/src/ecommerce/categoria/index.html">RSS</a></li>
                    <li><a href="http://localhost/concursos_new/src/ecommerce/pedido/index.html">LOGIN</a></li>
              </ul>
    </div>
      </div>
        <div id="top-panel">
            <div id="panel">
                <ul>
                    <li><a href="http://localhost/concursos_new/src/ecommerce/produto/showCreateForm.html" class="report">Últimos Inscritos</a></li>
                    <li><a href="#" class="report_seo">Relatório de Pagos</a></li>
                    <li><a href="#" class="search">Total Arrecadado no Dia</a></li>
                    <li><a href="#" class="feed">RSS Últimas Inscrições</a></li>
                </ul>
            </div>
      </div>
        <div id="wrapper">
            <div id="content">
              <?php 
              $frontController=_AutoLoad::getFrontController();
              $frontController->listering();
              $frontController->run();
	           ?>
            </div>
            <div id="sidebar">
  				<ul>
                	<li><h3><a href="#" class="house">Principal</a></h3>
                        <ul>
                        	<li><a href="#" class="report">Últimos Inscrits</a></li>
                    		<li><a href="#" class="report_seo">Relatório de pagos</a></li>
                            <li><a href="#" class="search">Total Arrecadado dia</a></li>
                        </ul>
                    </li>
                    <li><h3><a href="#" class="folder_table">Curso</a></h3>
          				<ul>
                        	<li><a href="#" class="addorder">Criar Novo Curso</a></li>
                          <li><a href="#" class="shipping">Gerenciar Certificado</a></li>
                            <li><a href="#" class="invoices">Configurações Globais</a></li>
                        </ul>
                    </li>
                    <li><h3><a href="#" class="manage">Gerenciamento</a></h3>
          				<ul>
                            <li><a href="#" class="manage_page">Notificações</a></li>
                            <li><a href="#" class="cart">Relatórios de Pagos</a></li>
                            <li><a href="#" class="folder">Relatórios por Cargos</a></li>
							<li><a href="#" class="addorder">Relatórios por Curso</a></li>
            				<li><a href="#" class="promotions">Promoções</a></li>
                        </ul>
                    </li>
                  <li><h3><a href="#" class="user">Usuarios</a></h3>
          				<ul>
                            <li><a href="#" class="useradd">Add Usuário</a></li>
                            <li><a href="#" class="group">Grupos de Usuários</a></li>
            				<li><a href="#" class="search">Buscar Usuários</a></li>
                            <li><a href="#" class="online">Usuários On line</a></li>
                        </ul>
                    </li>
				</ul>				
          </div>
      </div>
        <div id="footer">
        <div id="credits">
   		Template by <a href="http://www.bloganje.com">Bloganje</a>
        </div>
        <div id="styleswitcher">
            <ul>
                <li><a href="javascript: document.cookie='theme='; window.location.reload();" title="Default" id="defswitch">d</a></li>
                <li><a href="javascript: document.cookie='theme=1'; window.location.reload();" title="Blue" id="blueswitch">b</a></li>
                <li><a href="javascript: document.cookie='theme=2'; window.location.reload();" title="Green" id="greenswitch">g</a></li>
                <li><a href="javascript: document.cookie='theme=3'; window.location.reload();" title="Brown" id="brownswitch">b</a></li>
                <li><a href="javascript: document.cookie='theme=4'; window.location.reload();" title="Mix" id="mixswitch">m</a></li>
            </ul>
        </div><br />
        </div>
</div>
</body>
</html>