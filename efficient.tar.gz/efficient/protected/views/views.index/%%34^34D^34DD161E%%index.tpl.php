<?php /* Smarty version 2.6.21, created on 2013-05-22 02:24:11
         compiled from c:/wamp/www/oabpiCms/protected/views/views.index/index.tpl */ ?>
﻿<?php 
	    $user=new authUsers();
        $user->authStart();
        $user->startSessionVerify();
        $user->sessionClose();
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Dashboard - Admin Template</title>
	<script src="media/js/nicEdit.js" type="text/javascript"></script>
   <?php echo '
    <script type="text/javascript">

bkLib.onDomLoaded(function() {
	new nicEditor({
		//buttonList : [\'bold\',\'italic\',\'underline\',\'upload\'],
		//iconsPath:\'nicEditorIcons.gif\',
		uploadURI : \'main.php\', 
	}).panelInstance(\'textareaId\');
});

</script>
	'; ?>

        <?php Partial::init()->module('ApplicationController')->message('css'); ?>
        <?php Partial::init()->module('ApplicationController')->message('styleSettings'); ?>
        <?php Partial::init()->module('ApplicationController')->message('javascripts'); ?>
        <?php Partial::init()->module('ApplicationController')->message('datatables'); ?>

<link rel="stylesheet" type="text/css" href="http://localhost/oabpi/esapi_admin/css/theme.css" />
<link rel="stylesheet" type="text/css" href="http://localhost/oabpi/esapi_admin/css/style.css" />
<link rel="stylesheet" type="text/css" href="http://localhost/oabpi/esapi_admin/css/theme1.css" /><!--[if IE]>
<link rel="stylesheet" type="text/css" href="/oabpi/esapi_admin/css/theme.css" />
<link rel="stylesheet" type="text/css" href="/oabpi/esapi_admin/css/style.css" />
<link rel="stylesheet" type="text/css" href="css/ie-sucks.css" />
<![endif]-->
<?php 
Partial::init()->module('ApplicationController')->message('globalAjaxRequest');
 ?>
<?php 
Partial::init()->module('ApplicationController')->message('jqueryUiLoad');
 ?>
 <script type="text/javascript" src="media/js/lightbox/js/jquery.lightbox-0.5.js"></script>
 <link rel="stylesheet" type="text/css" href="media/js/lightbox/css/jquery.lightbox-0.5.css" media="screen" />
 <link rel="stylesheet" type="text/css" href="media/js/chosen/chosen/chosen.css" media="screen" />

<script>
   var StyleFile = "theme" + document.cookie.charAt(6) + ".css";
   document.writeln('<link rel="stylesheet" type="text/css" href="<?php echo ConfigPath::pathRoot()  ?>concursos_new/src/ecommerce/media/admin_template/css/' + StyleFile + '">');
</script>
<!--[if IE]>
<link rel="stylesheet" type="text/css" href="css/ie-sucks.css" />
<![endif]-->
<?php echo '
<script type="text/javascript">
    $(function() {
        $(\'#gallery a\').lightBox();
		$(\'div .gallery a\').lightBox();
    });
    </script>
'; ?>


<?php echo '
<link rel="stylesheet" type="text/css" media="screen" href="media/examplefiles/css/all-examples.css">	
'; ?>

</head>

<body><!-- end div .dock #dock -->
	<!-- END DOCK 1 ============================================================ -->
	
	<!-- BEGIN DOCK 2 ============================================================ -->
	<!-- END DOCK 2 ============================================================ -->
	
	
<!-- Accordion -->
	<div id="container">
    	<div id="header">
        	<h1 class="topologo"><img src="<?php  echo ConfigPath::pathRoot() ?>concursos_new/src/ecommerce/media/images/esapilogo.jpg" /></h1>
    <div id="topmenu">
            	<ul>
                	<li class="current"><a href="index.php">Principal</a></li>
                    <li><a href="?class=diretorios&method=listar">Diretórios</a></li>
					<li><a href="?class=tags&method=listar">Tags Arquivos</a></li>
					<li><a href="?class=arquivos&method=listar">Arquivos</a></li>
					<li><a href="?class=categorias&method=show">Categorias</a></li>
					<li><a href="?class=subCategoria&method=show">SubCategorias</a></li>
					
					<!--<li><a href="?class=videos&method=show">Videos</a></li>-->
					<li><a href="?class=paginas&method=show">Páginas</a></li>
              </ul>
          </div>
      </div>
        <div id="top-panel">
            <div id="panel">
                <ul>
                    <li><a href="<?php  echo ConfigPath::pathRoot() ?>concursos_new/src/ecommerce/produto/showCreateForm.html" class="report">Administração de Usuarios</a></li>
                    <li><a href="#" class="search">Histórico de ações</a></li>
                </ul>
            </div>
      </div>
        <div id="wrapper">
            <div id="content">
              <?php 
				$frontController =_AutoLoad::getFrontController();
				$frontController->listering();
				$frontController->run();
	           ?>
            </div>
            <div id="sidebar">
  				<ul>
                    <li><h3><a href="#" class="folder_table">Páginas</a></h3>
          				<ul>
                        	<li><a href="?class=paginas&method=indexNew" class="addorder">Criar Página</a></li>
                          <li><a href="?class=paginas&method=show" class="shipping">Ver Todas as páginas</a></li>
                            <li><a href="?class=categorias&method=indexNew" class="invoices">Criar Categorias</a></li>
                            <li><a href="?class=subCategoria&method=indexNew" class="invoices">Criar SubCateogiras</a></li>
                        </ul>
                    </li>
                    <li><h3><a href="#" class="manage">Diretórios</a></h3>
          				<ul>
                            <li><a href="?class=diretorios&method=adicionar" class="manage_page">Criar Diretório</a></li>
                            <li><a href="?class=diretorios&method=listar" class="cart">Ver todos os Diretórios</a></li>
                            <li><a href="?class=tags&method=listar" class="folder">Criar Tags</a></li>
							<li><a href="?class=arquivos&method=listar" class="addorder">Arquivos</a></li>
                        </ul>
                    </li>
					
					<li><h3><a href="?class=newslleter&method=show" class="manage">Newslleter</a></h3>
          				<ul>
                            <li><a href="?class=newslleter&method=show" class="cart">Gerenciar</a></li>	
                        </ul>
                    </li>
					
					<li><h3><a href="?class=videos&method=show" class="manage">Videos</a></h3>
          				<ul>
                            <li><a href="?class=videos&method=show" class="cart">Gerenciar</a></li>	
                            <li><a href="?class=videos&method=indexNew" class="cart">Adicionar</a></li>	
                        </ul>
                    </li>
					
                  <li><h3><a href="#" class="user">Usuarios</a></h3>
          				<ul>
                            <li><a href="?class=usuarios&method=add" class="useradd">Criar Usuario</a></li>
                            <li><a href="#" class="group">Permissões de Usuário</a></li>
            				<li><a href="#" class="search">Editar Perfil</a></li>
                            <li><a href="#" class="online">Ver Todos os Usuarios</a></li>
                            <li><a href="?doLogout=true" class="online">Logout </a></li>
                        </ul>
                    </li>
				</ul>				
          </div>
      </div>
        <div id="footer">
        <div id="credits">
   		Template by <a href="http://www.bloganje.com">Bloganje</a>
        </div>
        <div id="styleswitcher">
            <ul>
                <li><a href="javascript: document.cookie='theme='; window.location.reload();" title="Default" id="defswitch">d</a></li>
                <li><a href="javascript: document.cookie='theme=1'; window.location.reload();" title="Blue" id="blueswitch">b</a></li>
                <li><a href="javascript: document.cookie='theme=2'; window.location.reload();" title="Green" id="greenswitch">g</a></li>
                <li><a href="javascript: document.cookie='theme=3'; window.location.reload();" title="Brown" id="brownswitch">b</a></li>
                <li><a href="javascript: document.cookie='theme=4'; window.location.reload();" title="Mix" id="mixswitch">m</a></li>
            </ul>
        </div><br />
        </div>
</div><?php echo '
<script src="media/js/chosen/chosen/chosen.jquery.js" type="text/javascript"></script>
  <script type="text/javascript"> $(".chzn-select").chosen(); $(".chzn-select-deselect").chosen({allow_single_deselect:true}); </script>
  <script type="text/javascript"> $(".chzn-select_cat").chosen(); $(".chzn-select-deselect").chosen({allow_single_deselect:true}); </script>
'; ?>

  </body>
</h
tml>