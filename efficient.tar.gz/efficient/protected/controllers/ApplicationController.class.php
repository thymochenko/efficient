<?php
class ApplicationController extends ControllerFactory
{
    function menu()
	{
	    $this->staticRender(array(
	        'view_dirname'=>'index',
		    'tpl_name'=>'menu',
		    'extension'=>'html')
		);
	}

    public function css()
	{
		echo '<link rel="stylesheet" href="' . ConfigPath::pathRoot() . 'efficient/media/css/style.css" />';
    }

    public function javascripts()
	{
	    echo '
		 <script type="text/javascript" language="javascript" src="' . ConfigPath::pathRoot() . 'efficient/media/datatables/media/js/jquery.js"></script>
		<script type="text/javascript" language="javascript" src="' . ConfigPath::pathRoot() . 'efficient/media/datatables/media/js/jquery.dataTables.js"></script>
		';
	}
		
	public function colorBoxSettings()
	{
	    echo '';
	}
			
        public function datatables()
		{
	        echo'<script type="text/javascript" charset="iso-8859-1">

			$(document).ready(function() { 

				oTable = $("#example").dataTable({ 
					"bJQueryUI": true,
					"sPaginationType": "full_numbers",
					"aaSorting": [[ 0, "asc"]],
					"iDisplayLength": 30
				});
			} );
		    </script>';
	    }
		
		public function styleSettings(){

	        echo '<style type="text/css" title="currentStyle">
			@import "' . ConfigPath::pathRoot() .'efficient/media/datatables/media/css/demo_page.css";

			@import "' . ConfigPath::pathRoot() . 'efficient/media/datatables/media/css/demo_table_jui.css";

			@import "' . ConfigPath::pathRoot() . 'efficient/media/datatables/examples/examples_support/themes/smoothness/jquery-ui-1.8.4.custom.css";
			</style>';
	    }
		
		public function globalAjaxRequest()
		{
		    echo '<script type="text/javascript" language="javascript" src="'. ConfigPath::pathRoot() . 'oabpiCms/media/js/ajax.js"></script>';
		}
		
		public function jqueryUiLoad()
		{
		    echo '<link href="' . ConfigPath::pathRoot() . 'oabpiCms/media/jquery-ui/jquery-ui/css/ui-lightness/jquery-ui-1.9.1.custom.css" rel="stylesheet">
	        <script src="'. ConfigPath::pathRoot() . 'oabpiCms/media/jquery-ui/jquery-ui/js/jquery-ui-1.9.1.custom.js"></script>';
		}
		
		public function createButtom()
		{
		    echo '<script>
            $(function() {
            $("button")
            .button()
            .click(function( event ) {
                $(window.location).attr("href","?class=diretorios&method=adicionar")
                });
            });
            </script>';
		}
		
		public function buttomTags()
		{
		    echo '<script>
            $(function() {
            $("#tags_buttom")
            .button()
            .click(function( event ) {
                $(window.location).attr("href","?class=tags&method=listar")
                });
            });
            </script>';
		}
		
		public function buttomArquivos()
		{
		    echo '<script>
            $(function() {
            $("#arquivos_buttom")
            .button()
            .click(function( event ) {
                $(window.location).attr("href","?class=arquivos&method=listar")
                });
            });
            </script>';
		}
		
		public function buttomTagsAdd()
		{
		    echo '<script>
            $(function() {
            $("#tagsAdd")
            .button()
            .click(function( event ) {
                $(window.location).attr("href","?class=tags&method=adicionar")
                });
            });
            </script>';
		}
		
		
		public function buttomCategoryAdd()
		{
		    echo '<script>
            $(function() {
            $("#categoryAdd")
            .button()
            .click(function( event ) {
                $(window.location).attr("href","?class=categorias&method=indexNew")
                });
            });
            </script>';
		}
		
		
		public function buttomSubCategoryAdd()
		{
		    echo '<script>
            $(function() {
            $("#subCategoryAdd")
            .button()
            .click(function( event ) {
                $(window.location).attr("href","?class=subCategoria&method=indexNew")
                });
            });
            </script>';
		}
		
		public function buttomNewslleterAdd()
		{
		    echo '<script>
            $(function() {
            $("#newslleterAdd")
            .button()
            .click(function( event ) {
                $(window.location).attr("href","?class=newslleter&method=indexNew")
                });
            });
            </script>';
		}
		
		public function buttomVideosAdd()
		{
		    echo '<script>
            $(function() {
            $("#videosAdd")
            .button()
            .click(function( event ) {
                
                });
            });
            </script>';
		}
		
		public function buttomCategoriasAdd()
		{
		    echo '<script>
            $(function() {
            $("#categoriasAdd")
            .button()
            .click(function( event ) {
                
                });
            });
            </script>';
		}
		
		public function buttomSubCategoriasAdd()
		{
		    echo '<script>
            $(function() {
            $("#SubCategoriasAdd")
            .button()
            .click(function( event ) {
                
                });
            });
            </script>';
		}
		
		
		public function buttomArquivosAdd()
		{
		    echo '<script>
            $(function() {
            $("#ArquivosAdd")
            .button()
            .click(function( event ) {
                $(window.location).attr("href","?class=arquivos&method=adicionar")
                });
            });
            </script>';
		}
		
		public function buttomPaginasAdd()
		{
		    echo '<script>
            $(function() {
            $("#paginasAdd")
            .button()
            .click(function( event ) {
                $(window.location).attr("href","?class=paginas&method=indexNew")
                });
            });
            </script>';
		}
		
		public function buttomDiretoriosAdd()
		{
		    echo '<script>
            $(function() {
            $("#diretoriosAdd")
            .button()
            .click(function( event ) {
                });
            });
            </script>';
		}
		
		public function buttomListInputs()
		{
		    echo '<script>
            $(function() {
            $("#ArquivosAdd")
            .button()
            .click(function( event ) {
                $(window.location).attr("href","main.php?class=arquivos&method=listar")
                });
            });
            </script>';
		}
	
}
?>