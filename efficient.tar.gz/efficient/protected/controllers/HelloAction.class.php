<?php
/**
 * Description of HelloAction
 *
 * @author Thymochenko
 */
class HelloAction extends ApplicationController {

    /**
     * @NoTransactional
     */
    public function hello() {
        Message::_get('Info', "Ola grande " . $this->request()->get('stdClass')->nome);
    }
}