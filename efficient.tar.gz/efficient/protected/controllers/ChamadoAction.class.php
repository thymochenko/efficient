<?php
class ChamadoAction extends ApplicationController
{
    public function add()
	{
	    $this->render(array(
		    'collection'=>array(null), 'template'=>'add')
	    );
	}
	
	public function store()
	{
		if($this->request()->post())
		{
			$chamado = new Chamado;
			$chamado->fromArray($this->request()->post());
			if($chamado->store())
			{
				Message::_get('Info', '<h1>Chamado Registrado com sucesso</h1>');
			}
			else
			{
			    $errorMessage = utf8_encode('<h2>' . SessionRegistry::getValue('error') . '</h2>');
			    Message::_get('Error',$errorMessage);
			}
		}
	}
	
	/**
	*@Transactional
	*/
	public function indexBoxWidget()
	{
		Transaction::open();
		$this->render(array('collection'    
			=>Model::object('Chamado')->getChamadosParaPaginaInicial($limit=8),
			'template'=>'indexBoxWidget')
		);
		
		Transaction::close();
	}
	
	public function listAll()
	{
		
		$this->render(array('collection'
			=>Model::object('Chamado')->finder()->findAll(),
			'template'=>'listAll')
		);
		
	}
}
?>