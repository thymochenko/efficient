$(function(){
        $("#dialog-form_subcat").load("main.php?class=subCategoria&method=indexNew").dialog({
            autoOpen: false,
            height: 350,
            width: 800,
            modal: false,
            buttons:{
                Cancel: function(){
                    $(this).dialog("close");
                }
            },
            close: function(){
               $(this).dialog("close");
            }
        });
		
        $("#SubCategoriasAdd")
            .button()
            .click(function(){
                $( "#dialog-form_subcat" ).dialog("open");
            });			
		});