/**
$(): utilizado em todas as fun��es que devem ser referenciadas a jQuery
document: express�o que indica o documento HTML
ready(): associado a leitura do documento enquanto est� sendo carregado
*/

$(document).ready(function()
{
    // Crio uma vari�vel chamada $forms que pega o valor da tag form
    
		$('.actionFormSendDiretorios_').unbind('submit').bind('submit', function(e){
			
        /**
        Crio a vari�vel $button
        attr(): set a propriedade de um atributo, nesse exemplo foi desativado o bot�o com a tag button
        */
		e.preventDefault();
        
		var $button = $('button',this).attr('disabled',true);
        /**
        Criada a vari�vel params
        serialize(): pega os dados inseridos no formul�rio
        */
        var params = $(this.elements).serialize();
        //window.alert(params); 
        var self = this;
        $.ajax({
            // Usando metodo Post
            type: 'POST',
            // this.action pega o script para onde vai ser enviado os dados
            url: this.action,
            // os dados que pegamos com a fun��o serialize()
            data: params, 
            // Antes de enviar
            beforeSend: function(){
                // mostro a div loading
                $('#loadingDir').show();
                //  html(): equivalente ao innerHTML
                $('#loadingDir').html("<h2>Carregando...</h2>");
				
            },
            success: function(txt)
			{
                // Ativo o bot�o usando a fun��o attr()
                $button.attr('disabled',false);
                $('#loadingDir').html("<h2>Inserido com Sucesso</h2>");
				//recebe uma resposta Json
				obj = jQuery.parseJSON(txt);
				//adiciona um elemento option contendo o id e a descricao do obj
				$('#insertObjDir',opener.document).prepend('<option value="' + obj.id + '">' + obj.nome	+ '</option>');
                //atualiza a lista carregada pelo citzen para refletir a inser��o do new el.
				$('.chzn-select').trigger("liszt:updated");
                //reseta form.
				self.reset();
				window.close();
            },
            // Se acontecer algum erro � executada essa fun��o
            error: function(txt){
                $('#loading').html("ERRO");
            }
        })
        return false;
    });
});


$(document).ready(function()
{
    // Crio uma vari�vel chamada $forms que pega o valor da tag form
    
	
		$('.actionFormSendDiretoriosUpd').unbind('submit').bind('submit', function(e){
			
        /**
        Crio a vari�vel $button
        attr(): set a propriedade de um atributo, nesse exemplo foi desativado o bot�o com a tag button
        */
		e.preventDefault();
        
		var $button = $('button',this).attr('disabled',true);
        /**
        Criada a vari�vel params
        serialize(): pega os dados inseridos no formul�rio
        */
        var params = $(this.elements).serialize();
        //window.alert(params); 
        var self = this;
        $.ajax({
            // Usando metodo Post
            type: 'POST',
            // this.action pega o script para onde vai ser enviado os dados
            url: this.action,
            // os dados que pegamos com a fun��o serialize()
            data: params, 
            // Antes de enviar
            beforeSend: function(){
                // mostro a div loading
                $('#loadingDir').show();
                //  html(): equivalente ao innerHTML
                $('#loadingDir').html("<h2>Carregando...</h2>");
				
            },
            success: function(txt)
			{
                // Ativo o bot�o usando a fun��o attr()
                $button.attr('disabled',false);
                alert("Inserido com Sucesso");
				//atualiza a lista carregada pelo citzen para refletir a inser��o do new el.
				$('.chzn-select').trigger("liszt:updated");
                //reseta form.
				self.reset();
				window.close();
            },
            // Se acontecer algum erro � executada essa fun��o
            error: function(txt){
                $('#loading').html("ERRO");
            }
        })
        return false;
    });
});